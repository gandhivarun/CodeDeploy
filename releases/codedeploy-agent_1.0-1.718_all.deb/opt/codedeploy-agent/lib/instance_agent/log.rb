require 'process_manager/log'

InstanceAgent::Log = ProcessManager::Log
